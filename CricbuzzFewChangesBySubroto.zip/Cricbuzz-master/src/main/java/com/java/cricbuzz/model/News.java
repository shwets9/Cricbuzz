package com.java.cricbuzz.model;

public class News {
	int ID;
	String Title;
	
	public News() {
		super();
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	@Override
	public String toString() {
		return "" + Title;
	}

	public News(int iD, String title) {
		super();
		ID = iD;
		Title = title;
	}
	
	
	

}
