package com.java.cricbuzz.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.java.cricbuzz.model.Player;

public interface PlayerRepository  extends MongoRepository<Player, String>{
	
	public Player findByPlayerNameIgnoreCase(String playerName);
}
