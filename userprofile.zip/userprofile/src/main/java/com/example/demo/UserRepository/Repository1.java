package com.example.demo.UserRepository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.UserModel.UserProfile;

@Repository

	
	public interface Repository1 extends MongoRepository<UserProfile, String> {
		public UserProfile findByEmail(String email);
		public UserProfile findByPhone(String phone);
}
