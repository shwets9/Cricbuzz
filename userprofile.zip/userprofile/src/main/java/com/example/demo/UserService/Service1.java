package com.example.demo.UserService;

import org.apache.catalina.startup.ClassLoaderFactory.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.UserModel.UserProfile;
import com.example.demo.UserRepository.Repository1;

@Service
public class Service1 {


		@Autowired
		private Repository1 repository;
		
		public UserProfile create(String name, String password, String phone, String email, String address,boolean paid) {
			return repository.save(new UserProfile(name,password,phone,email,address,paid));
			
		}
		public UserProfile update(String name, String password, String phone, String email, String address,boolean paid) {
			UserProfile userprofile=repository.findByEmail(email);
			userprofile.setName(name);
			userprofile.setPassword(password);
			userprofile.setEmail(email);
			userprofile.setPhone(phone);
			userprofile.setAddress(address);
			userprofile.setPaid(paid);
			return repository.save(userprofile);
		}
		public void delete(String email) {
		UserProfile userprofile=repository.findByEmail(email);
		repository.delete(userprofile);
		}
		public UserProfile findByEmail(String email) {
			return repository.findByEmail(email);
		}
		
		public UserProfile findByPhone(String phone) {
			return repository.findByPhone(phone);
		}
		
}
