package com.java.cricbuzz.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.java.cricbuzz.model.Player;
import com.java.cricbuzz.repository.PlayerRepository;

@Service
public class PlayerService {
	
	@Autowired
	private PlayerRepository playerRepository;
	
	public Player getPlayer(String playerName)
	{
		return playerRepository.findByPlayerName(playerName);
	}

}
