package com.java.cricbuzz.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Player")
public class Player {
	
	@Id
	String id;
	
	String playerName;
	String national_Side;
	String born;
	String height;
	String batting;
	String bowling;
	String role;
	
	public Player() {
		super();
	}
	
	public Player(String playerName, String national_Side, String born, String height, String batting, String bowling,
			String role) {
		super();
		this.playerName = playerName;
		this.national_Side = national_Side;
		this.born = born;
		this.height = height;
		this.batting = batting;
		this.bowling = bowling;
		this.role = role;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public String getNational_Side() {
		return national_Side;
	}

	public void setNational_Side(String national_Side) {
		this.national_Side = national_Side;
	}

	public String getBorn() {
		return born;
	}

	public void setBorn(String born) {
		this.born = born;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getBatting() {
		return batting;
	}

	public void setBatting(String batting) {
		this.batting = batting;
	}

	public String getBowling() {
		return bowling;
	}

	public void setBowling(String bowling) {
		this.bowling = bowling;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "Player [playerName=" + playerName + ", national_Side=" + national_Side + ", born=" + born + ", height="
				+ height + ", batting=" + batting + ", bowling=" + bowling + ", role=" + role + "]";
	}

}
